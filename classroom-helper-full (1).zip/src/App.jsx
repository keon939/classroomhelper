import React, { useEffect, useState, useRef } from "react";
import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";
import {
  getFirestore,
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
} from "firebase/firestore";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
} from "firebase/storage";

// Firebase config (replace with your own)
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

const App = () => {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  const [audioURL, setAudioURL] = useState(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);

  const roleByEmail = {
    "admin@classroom.com": "admin",
    "moderator@classroom.com": "moderator",
  };

  const userRole = roleByEmail[user?.email] || "student";

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    const q = query(collection(db, "messages"), orderBy("timestamp"));
    const unsubMessages = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map((doc) => doc.data()));
    });

    return () => {
      unsubscribe();
      unsubMessages();
    };
  }, []);

  const handleLogin = () => {
    signInWithEmailAndPassword(auth, email, password).catch(alert);
  };

  const handleRegister = () => {
    createUserWithEmailAndPassword(auth, email, password).catch(alert);
  };

  const handleLogout = () => {
    signOut(auth);
  };

  const sendMessage = async () => {
    if (!message && !audioURL) return;

    let audio = null;
    if (audioURL) {
      const response = await fetch(audioURL);
      const blob = await response.blob();
      const audioRef = ref(storage, `voicemails/${Date.now()}.webm`);
      await uploadBytes(audioRef, blob);
      audio = await getDownloadURL(audioRef);
    }

    await addDoc(collection(db, "messages"), {
      text: message,
      user: user.email,
      audio: audio,
      timestamp: new Date(),
    });

    setMessage("");
    setAudioURL(null);
  };

  const startRecording = async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorderRef.current = new MediaRecorder(stream);
    mediaRecorderRef.current.ondataavailable = (e) => {
      audioChunksRef.current.push(e.data);
    };
    mediaRecorderRef.current.onstop = () => {
      const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
      const url = URL.createObjectURL(audioBlob);
      setAudioURL(url);
      audioChunksRef.current = [];
    };
    mediaRecorderRef.current.start();
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
    }
  };

  if (!user) {
    return (
      <div className="p-4 max-w-sm mx-auto">
        <h1 className="text-2xl font-bold mb-4">Login / Register</h1>
        <input
          className="border p-2 w-full mb-2"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          className="border p-2 w-full mb-2"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button onClick={handleLogin} className="bg-blue-500 text-white px-4 py-2 mr-2 rounded">
          Login
        </button>
        <button onClick={handleRegister} className="bg-green-500 text-white px-4 py-2 rounded">
          Register
        </button>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Classroom Helper</h1>
        <div>
          <span className="mr-2">{user.email} ({userRole})</span>
          <button onClick={handleLogout} className="bg-red-500 text-white px-4 py-1 rounded">
            Logout
          </button>
        </div>
      </div>

      {userRole === "admin" && (
        <div className="mb-4 text-sm text-gray-700 font-semibold">
          ✅ Admin: You can post assignments and access everything students can.
        </div>
      )}

      <div className="mb-4">
        <input
          className="border p-2 w-full mb-2"
          type="text"
          placeholder="Write a message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <div className="flex gap-2">
          <button onClick={sendMessage} className="bg-blue-500 text-white px-4 py-2 rounded">
            Send
          </button>
          <button onClick={startRecording} className="bg-yellow-500 text-white px-4 py-2 rounded">
            🎙 Start Recording
          </button>
          <button onClick={stopRecording} className="bg-orange-500 text-white px-4 py-2 rounded">
            ⏹ Stop
          </button>
        </div>
        {audioURL && (
          <div className="mt-2">
            <audio controls src={audioURL} className="w-full"></audio>
          </div>
        )}
      </div>

      <div className="bg-gray-100 p-4 rounded shadow">
        <h2 className="font-semibold mb-2">Chat & Posts</h2>
        {messages.map((msg, idx) => (
          <div key={idx} className="mb-3 border-b pb-2">
            <div className="font-medium text-sm">{msg.user}</div>
            {msg.text && <div>{msg.text}</div>}
            {msg.audio && (
              <audio controls src={msg.audio} className="mt-1 w-full"></audio>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;